package com.creamakers.websystem.utils;

import com.github.houbb.sensitive.word.api.IWordDeny;
import com.github.houbb.sensitive.word.bs.SensitiveWordBs;
import com.github.houbb.sensitive.word.support.allow.WordAllows;
import com.github.houbb.sensitive.word.support.check.WordChecks;
import com.github.houbb.sensitive.word.support.replace.WordReplaces;
import com.github.houbb.sensitive.word.support.resultcondition.WordResultConditions;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;

public class SensitiveWordUtil {

    private static SensitiveWordBs wordBs = null;

    // 哈希表储存敏感词库，便于查重处理
    private static HashSet<String> sensitiveWordSet = new HashSet<>();

    // 用静态代码块初始化敏感词库，保证只初始化一次
    static{
        //初始化敏感词工具
        wordBs = SensitiveWordBs.newInstance()
                .wordDeny(new MyWordDeny())                                     // 敏感词检测策略
                .wordAllow(WordAllows.defaults())                               // 允许策略
                .wordReplace(WordReplaces.defaults())                           // 替换策略
                .wordResultCondition(WordResultConditions.englishWordNumMatch())// 英文单词+数字全词匹配
                .wordFailFast(false)                                            // 尽可能找到最长的匹配词
                .ignoreCase(true)                                               // 忽略大小写
                .ignoreWidth(true)                                              // 忽略半角圆角
                .ignoreNumStyle(true)                                           // 忽略数字样式
                .ignoreRepeat(true)                                             // 忽略重复字符
                .wordCheckNum(WordChecks.num())                                 // 数字检测策略
                .wordCheckEmail(WordChecks.email())                             // 邮箱检测策略
                .wordCheckUrl(WordChecks.url())                                 // URL校验策略
                .wordCheckIpv4(WordChecks.ipv4())                               // IPV4校验策略
                .enableNumCheck(true)                                           // 开启数字校验，过滤手机号和QQ号等广告
                .enableEmailCheck(true)                                         // 开启邮箱校验
                .enableUrlCheck(true)                                           // 开启URL校验
                .enableIpv4Check(true)                                          // 开启IPV4校验
                .init();                                                        // 初始化敏感词库
    }

    // 自定义敏感词检测策略，检测哪些敏感词
    public static class MyWordDeny implements IWordDeny {
        //文件读取敏感词的路径
        private static final String path = "src/main/resources/SensitiveWordTags.txt";
        @Override
        public List<String> deny() {
            // 初始化敏感词列表，文件读取
            List<String> fileReadSensitiveWords;
            try {
                fileReadSensitiveWords = Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            // 敏感词列表转换为Set，提高去重时的查询效率
            sensitiveWordSet.addAll(fileReadSensitiveWords);
            return fileReadSensitiveWords;
        }

    }
    /*
    * 敏感词过滤
    * 要求：传入一个字符串，判断是否包含敏感词。如果有进行脱敏处理
    * 脱敏处理：将敏感词中的每个字符替换为 *
    * */
    public String check(String word){
        boolean isSensitive = wordBs.contains(word);
        if(!isSensitive){
            // 不是敏感词，直接返回
            return word;
        }
        // 是敏感词，进行脱敏处理
        return wordBs.replace(word);
    }

    // 新增敏感词
    public boolean addSensitiveWord(String word){
        // 新增敏感词，先判断是否存在
        if(sensitiveWordSet.add(word)){
            wordBs.addWord(word);
            return true;
        }
        return false;
    }

    // 删除敏感词
    public boolean deleteSensitiveWord(String word){
        // 删除敏感词，先判断是否存在
        if(sensitiveWordSet.remove(word)){
            wordBs.removeWord(word);
            return true;
        }
        return false;
    }
}